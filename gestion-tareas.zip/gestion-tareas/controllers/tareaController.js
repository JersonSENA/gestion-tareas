const Tarea = require('../models/tarea'); // Importamos el modelo de tarea

// Obtener todas las tareas
exports.getAllTareas = (req, res) => {
    Tarea.getAll((err, tareas) => {
        if (err) {
            res.status(500).json({ error: 'Error al obtener las tareas' });
        } else {
            res.json(tareas);
        }
    });
};

// Crear una nueva tarea
exports.createTarea = (req, res) => {
    const nuevaTarea = req.body; // Obtenemos los datos de la solicitud
    Tarea.create(nuevaTarea, (err, result) => {
        if (err) {
            res.status(500).json({ error: 'Error al crear la tarea' });
        } else {
            res.json({ id: result.insertId }); // Devolvemos el ID de la nueva tarea
        }
    });
};

// Actualizar una tarea
exports.updateTarea = (req, res) => {
    const id = req.params.id; // Obtenemos el ID de la tarea de la URL
    const datosTarea = req.body; // Obtenemos los datos actualizados de la solicitud
    Tarea.update(id, datosTarea, (err) => {
        if (err) {
            res.status(500).json({ error: 'Error al actualizar la tarea' });
        } else {
            res.json({ message: 'Tarea actualizada correctamente' });
        }
    });
};

// Eliminar una tarea
exports.deleteTarea = (req, res) => {
    const id = req.params.id; // Obtenemos el ID de la tarea a eliminar
    Tarea.delete(id, (err) => {
        if (err) {
            res.status(500).json({ error: 'Error al eliminar la tarea' });
        } else {
            res.json({ message: 'Tarea eliminada correctamente' });
        }
    });
};
