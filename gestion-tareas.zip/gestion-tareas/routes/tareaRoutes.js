const express = require('express');
const router = express.Router();
const tareaController = require('../controllers/tareaController'); // Importamos el controlador

// Definimos las rutas y las vinculamos con las funciones del controlador
router.get('/', tareaController.getAllTareas);       // Obtener todas las tareas
router.post('/', tareaController.createTarea);       // Crear una nueva tarea
router.put('/:id', tareaController.updateTarea);     // Actualizar una tarea existente
router.delete('/:id', tareaController.deleteTarea);  // Eliminar una tarea

module.exports = router;  // Exportamos el router para usarlo en server.js
