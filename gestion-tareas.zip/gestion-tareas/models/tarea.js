const mysql = require('mysql2');

// Configuración de la conexión a la base de datos
const db = mysql.createConnection({
    host: 'localhost',   // Dirección del servidor de MySQL
    user: 'root',        // Tu usuario de MySQL
    password: '', // Tu contraseña de MySQL (cámbiala si es necesario)
    database: 'gestion_tareas' // Nombre de la base de datos
});

db.connect((err) => {
    if (err) throw err;
    console.log('Conectado a la base de datos MySQL');
});

// Operaciones sobre la tabla `tareas`
module.exports = {
    // Obtener todas las tareas
    getAll: (callback) => {
        db.query('SELECT * FROM tareas', callback);
    },

    // Crear una nueva tarea
    create: (data, callback) => {
        db.query('INSERT INTO tareas SET ?', data, callback);
    },

    // Actualizar una tarea
    update: (id, data, callback) => {
        db.query('UPDATE tareas SET ? WHERE id = ?', [data, id], callback);
    },

    // Eliminar una tarea
    delete: (id, callback) => {
        db.query('DELETE FROM tareas WHERE id = ?', [id], callback);
    }
};
